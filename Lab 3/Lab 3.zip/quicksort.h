#include <stdio.h>

void quickSort(int *a, size_t n);

int partition(int array[], int low, int high);