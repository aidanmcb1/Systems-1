#include <stddef.h>

void quicksort_optimized_XOR(int *a, int high, int low);

int partition_xor(int array[], int low, int high);