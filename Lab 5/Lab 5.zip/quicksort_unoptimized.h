#include <stddef.h>

void quicksort_unoptimized(int *a, int high, int low);

int partition(int array[], int low, int high);