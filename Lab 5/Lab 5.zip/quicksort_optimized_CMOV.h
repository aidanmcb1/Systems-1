#include <stddef.h>

void quicksort_optimized_CMOV(int *a, int high, int low);

int partition_cmov(int array[], int low, int high);