#ifndef edit_distance_h

#define edit_distance_h
#include <stdlib.h>

int editDistance(const char *string1, const char *string2, size_t length);

#endif
